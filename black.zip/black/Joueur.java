import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Joueur {
    
    public Carte[] cartes = new Carte[52];//creation du paquet de cartes
    private int Nb = 0,rand;
    private String nom;
    private int valeur = 0,som=0;
    private Image[] img=new Image[52];
    private ImageView[] imgV=new ImageView[52];
    private Image imgR;
    
    public void SetImgR(Image i){
	this.imgR=i;
    }
    
    public Image getImgR(){
	return this.imgR;
    }
    
    public Joueur(String nom) {
	this.nom = nom;
    }
    
    public int carteEnMAin() {
	return Nb;
    }
    
    public Carte prise(Carte d) {
	cartes[Nb++] = d;
	return d;
    }
    
    public void fin() {
	Nb = 0;
	som =0;
	valeur = 0;
    }
    
    public int Force(){
	valeur=0;
	for(int i=0;i<=51;i++){
	    img[i]=new Image(""+(i)+".png");	
	    imgV[i]=new ImageView(img[i]);
	}//As
	if((imgV[0]==imgV[rand])||(imgV[1]==imgV[rand])||(imgV[2]==imgV[rand])||(imgV[3]==imgV[rand])){
	    return valeur+=11;
	} //2 
   	else if((imgV[13]==imgV[rand])||(imgV[14]==imgV[rand])||(imgV[28]==imgV[rand])||(imgV[40]==imgV[rand])){
	    return valeur+=2;
	} //3
	else if((imgV[15]==imgV[rand])||(imgV[27]==imgV[rand])||(imgV[39]==imgV[rand])||(imgV[41]==imgV[rand])){
	    return valeur+=3;
	} //4
	else if((imgV[16]==imgV[rand])||(imgV[26]==imgV[rand])||(imgV[29]==imgV[rand])||(imgV[42]==imgV[rand])){
	    return valeur+=4;
	} //5
	else if((imgV[4]==imgV[rand])||(imgV[17]==imgV[rand])||(imgV[30]==imgV[rand])||(imgV[43]==imgV[rand])){
	    return valeur+=5;
	} //6
	else if((imgV[5]==imgV[rand])||(imgV[18]==imgV[rand])||(imgV[31]==imgV[rand])||(imgV[44]==imgV[rand])){
	    return valeur+=6;
	} //7
 	else if((imgV[6]==imgV[rand])||(imgV[19]==imgV[rand])||(imgV[32]==imgV[rand])||(imgV[45]==imgV[rand])){
	    return valeur+=7;
	} //8
	else if((imgV[7]==imgV[rand])||(imgV[20]==imgV[rand])||(imgV[33]==imgV[rand])||(imgV[46]==imgV[rand])){
	    return valeur+=8;
	} //9
	else if((imgV[8]==imgV[rand])||(imgV[21]==imgV[rand])||(imgV[34]==imgV[rand])||(imgV[47]==imgV[rand])){
	    return valeur+=9;
	} // 10
	else if((imgV[9]==imgV[rand])||(imgV[22]==imgV[rand])||(imgV[35]==imgV[rand])||(imgV[48]==imgV[rand])){
	    return valeur+=10;
	} //J
	else if((imgV[10]==imgV[rand])||(imgV[23]==imgV[rand])||(imgV[36]==imgV[rand])||(imgV[49]==imgV[rand])){
	    return valeur+=10;
	} //Q
 	else if((imgV[11]==imgV[rand])||(imgV[24]==imgV[rand])||(imgV[37]==imgV[rand])||(imgV[50]==imgV[rand])){
	    return valeur+=10;
	} //K
	else if((imgV[12]==imgV[rand])||(imgV[25]==imgV[rand])||(imgV[38]==imgV[rand])||(imgV[51]==imgV[rand])){
	    return valeur+=10;
	} //fin
	return 0;
    }
    
    public void setRand(int r){
	this.rand=r;
    }
    
    public int Valeur(){
	som+=this.valeur;
	return som;
    }
}
