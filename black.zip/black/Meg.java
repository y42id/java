import javafx.application.Application;
import javafx.event.ActionEvent;
import java.util.Random;
import java.lang.Math;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class Meg extends Application{
    private HBox hbCarteJ1=new HBox(),hbCarteJ2=new HBox(),hbCarteDos = new HBox(), hbox = new HBox(), hbox1 = new HBox();
    private boolean laoupas=true;
    private Button btnJouer,btnAide,btnQuitter,btnPiocher,btnRester,btnResultat;
    private Button btnRe=new Button("retour");
    private Image[] imgJ1 = new Image[52];
    private ImageView[] ivJ1 = new ImageView[52];
    private int resultatJ1=0,resultatJ2=0,n=0;
    public int randInt(int min,int max){
	Random rnd = new Random();
	int rand = rnd.nextInt((max - min)+1)+min;
	return rand;
    }
  
    private void init(Stage page){
        for(int i=0;i<=51;i++){
	    imgJ1[i]=new Image(""+(i)+".png");
	    ivJ1[i]=new ImageView(imgJ1[i]);
        }
	Group group=new Group();
	Scene scene=new Scene(group);
	Tas tasSurTable=new Tas();
	Joueur J1=new Joueur("Vous");
	Joueur J2=new Joueur("Croupier");
	btnAide=new Button("Aide");
	btnJouer=new Button("Jouer");
	btnQuitter=new Button("Quitter");
	btnPiocher=new Button("Piocher");
	btnRester=new Button("Rester");
	btnResultat=new Button("Resultat");
	btnRe.setVisible(false);
	btnResultat.setVisible(false);
	Image image=new Image("blackjacktable.png");
	ImageView imageViewBJT=new ImageView(image);
	/****************************************************
         ** creation de la setOnAction des tout les button **
	 ****************************************************/
	btnJouer.setOnAction(new EventHandler<ActionEvent>(){
		@Override
		public void handle(ActionEvent e) {
		    laoupas=true;
		    btnRe.setVisible(false);
		    btnJouer.setVisible(false);
		    btnAide.setVisible(false);
		    btnQuitter.setVisible(false);
		    btnPiocher.setVisible(true);
		    btnRester.setVisible(false);
		}
	    });
        btnRe.setOnAction(new EventHandler<ActionEvent>(){
		@Override
		public void handle(ActionEvent e) {
		    if(laoupas==true){
			btnRe.setVisible(false);
			btnResultat.setVisible(false);
			btnJouer.setVisible(true);
			btnAide.setVisible(true);
			btnQuitter.setVisible(true);
			btnPiocher.setVisible(false);
			btnRester.setVisible(false);
	        	hbCarteJ1.setVisible(false);
			hbCarteJ2.setVisible(false);
			hbCarteDos.setVisible(false);
			hbCarteJ1.getChildren().clear();
			hbCarteJ2.getChildren().clear();
			hbCarteDos.getChildren().clear();
			n=0;
			J1.fin();
			J2.fin();
			laoupas=false;
		    }
		}
	    });
        btnQuitter.setOnAction(new EventHandler<ActionEvent>(){
        	@Override
        	public void handle(ActionEvent e){
		    page.close();
        	}
	    });
        btnAide.setOnAction(new EventHandler<ActionEvent>(){
        	@Override
        	public void handle(ActionEvent e){
		    Stage aide=new Stage();
		    Group help=new Group();
		    Scene scene=new Scene(help);
    		    Image image = new Image("help.jpg");
    		    ImageView imageView =new ImageView(image);
    		    Button retour = new Button ("Retour");
    		    HBox hboxretour = new HBox();
    		    retour.setStyle("-fx-base: orange");
    		    hboxretour.getChildren().add(retour);
    		    help.getChildren().addAll(imageView,retour);
    		    aide.setScene(scene);
    		    aide.setTitle("HELP !!!!!!!");
    		    aide.show();
    		    aide.setResizable(false);
    		    retour.setOnAction(new EventHandler<ActionEvent>() {
    			    @Override public void handle(ActionEvent e) {
    				aide.close();
    			    }
    			});
        	}
	    });
        btnPiocher.setOnAction(new EventHandler<ActionEvent>(){
		@Override
        	public void handle(ActionEvent e){
		    btnRester.setVisible(true);
		    hbCarteJ1.setVisible(true);
		    hbCarteDos.setVisible(true);
		    int r = randInt(0,51);
		    Carte carteJ1= new Carte(0,0,"");
		    carteJ1 = J1.prise(tasSurTable.distribuer());
		    Image imgJ1 = new Image(""+(r)+".png");
		    ImageView ivJ1 = new ImageView(imgJ1);
		    J1.setRand(r);
		    if(n!=4){
			hbCarteJ1.getChildren().addAll(ivJ1);
			n++;
		    }
		    else{
			btnPiocher.setVisible(false);
			n=0;}
		    hbCarteJ1.setLayoutY(220);
		    hbCarteJ1.setLayoutX(120);
		    J1.Force();
	 	    resultatJ1 = J1.Valeur();
		}
	    });
        btnRester.setOnAction(new EventHandler<ActionEvent>(){
        	@Override
        	public void handle(ActionEvent e){
		    btnResultat.setVisible(true);
		    btnPiocher.setVisible(false);
		    hbCarteJ2.setVisible(false);
		    int j= randInt(2,4);
		    for(int i = j;i<6 ;++i ){
		    int r = randInt(0,51);
		    Carte carteJ2 = J2.prise(tasSurTable.distribuer());	    
		    Image imgJ2 = new Image(""+(r)+".png");
		    Image dos = new Image("dessus_carte.4.png");
		    ImageView ivJ2 = new ImageView(dos);
		    ImageView face = new ImageView(imgJ2);
		    J2.setRand(r);
		    hbCarteDos.getChildren().add(ivJ2);
		    hbCarteJ2.getChildren().add(face);
		    hbCarteJ2.setLayoutX(280);
		    hbCarteDos.setLayoutX(280);
		    hbCarteJ2.setLayoutY(75);
		    hbCarteDos.setLayoutY(75);
		    J2.Force();
		    resultatJ2 = J2.Valeur();
		    }
		    btnRester.setVisible(false);
		}
	    });
	btnResultat.setOnAction(new EventHandler<ActionEvent>(){
		@Override
		public void handle(ActionEvent e) {
		    laoupas=true;
		    Alert alert = new Alert(AlertType.INFORMATION);
		    alert.setTitle("Fin de la Partie");
		    alert.setHeaderText(null);
		    hbCarteDos.setVisible(false);
		    hbCarteJ2.setVisible(true);
		    btnRe.setVisible(true);
		    btnJouer.setVisible(false);
		    btnAide.setVisible(false);
		    btnQuitter.setVisible(false);
		    btnPiocher.setVisible(false);
		    btnRester.setVisible(false);
		    btnRe.setVisible(true);
		    if(resultatJ1 == 21){
			alert.setContentText("BLACKJACK !!!! Bravo t'as gagné!\nVotre  score est de: "+resultatJ1+ ". Score du croupier: " + resultatJ1);
			alert.showAndWait();
		    } else if(resultatJ2 == 21){
			alert.setContentText("BLACKJACK !!!! T'as perdu. \nVotre  score est de: "+resultatJ1+ ". Score du croupier: " + resultatJ1);
			alert.showAndWait();
		    } else if(resultatJ2 > 21){
			alert.setContentText("Le score du croupier a dépassé 21! Gagné!\nVoici ton score: "+resultatJ1+". Score du croupier: " +resultatJ2);
			alert.showAndWait();
		    } else if(resultatJ1 > 21){
			alert.setContentText("T'as dépassé 21! Dommage t'as perdu.\nVoici ton score: "+resultatJ1+ ". Score du croupier: " + resultatJ2);
			alert.showAndWait();
		    }else if((resultatJ1<21) && (resultatJ2<21)){
			if (resultatJ1 == resultatJ2) {
			alert.setContentText("Egalité !\nTon score est de: "+resultatJ1+ ". Score du croupier: " + resultatJ2);
			alert.showAndWait();
			}else if(resultatJ1>resultatJ2){
			alert.setContentText("Gagné !\nTon score est de: "+resultatJ1+ ". Score du croupier: " + resultatJ2);
			alert.showAndWait();
			}else if (resultatJ2>resultatJ1){
			alert.setContentText("Game over baby!\nTon score est de: "+resultatJ1+ ". Score du croupier: " + resultatJ2);
			alert.showAndWait();
			} 	
		    }
		}
	    });
	btnResultat.setStyle("-fx-background-color: #DB7337");
	btnRe.setStyle("-fx-background-color: #DB7337");
	btnJouer.setStyle("-fx-background-color: #DB7337");
	btnAide.setStyle("-fx-background-color: #DB7337");
	btnQuitter.setStyle("-fx-background-color: #DB7337");
	btnPiocher.setStyle("-fx-background-color: #DB7337");
	btnRester.setStyle("-fx-background-color: #DB7337");
	hbox1.getChildren().addAll(btnPiocher,btnRester,btnResultat);
	hbox.getChildren().addAll(btnJouer,btnAide,btnQuitter);
	hbox.setLayoutX(320);
	hbox.setLayoutY(225);
	hbox1.setLayoutX(320);
	hbox1.setLayoutY(370);
	btnAide.setVisible(true);
	btnQuitter.setVisible(true);
	btnPiocher.setVisible(false);
	btnRester.setVisible(false);
	group.getChildren().addAll(imageViewBJT,hbox,hbox1,btnRe,hbCarteJ1,hbCarteJ2,hbCarteDos);
	page.setScene(scene);
    }
    @Override
    public void start(Stage page){
	init(page);
	page.setResizable(false);
	page.show();
    }
    public static void main(String[] args) {launch(args);}
}
