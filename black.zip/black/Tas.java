
public class Tas {

    private Carte[] cartes;
    private int pioche =0;

    public Tas() {
        cartes = new Carte[52];
        for (int i = 0; i < 52; i++) {
                cartes[pioche] = new Carte(pioche, i ,""+ ".png");
                pioche++;
        }
    }

    public Carte distribuer() {
        return cartes[--pioche];
    }


    public int tailleTas() {
        return pioche;
    }

    public boolean Vide() {
        return (pioche == 0);
    }


    public void melanger() {
        for (int i = 0; i < pioche; i++) {
            int n = (int) (Math.random() * i);
            Carte rand = cartes[i];
            cartes[i] = cartes[n];
            cartes[n] = rand;
        }
    }
}
