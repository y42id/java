
public class Carte {

    private int carte;
    private int rang;
    private String front;

    Carte(int carte, int rang, String front) {
        this.carte = carte;
        this.rang = rang;
        this.front = front;
    }


    public int rang() {
	int val = 0;
	return val;
    }
    
    public String toString() {
	return this.front;
    }
}
